#!/bin/sh
#SBATCH -N 1
#SBATCH -n 32
#SBATCH --partition=cp1
#SBATCH --output=%j.out
#SBATCH --error=%j.err
#SBATCH --job-name=Test 
#SBATCH --export=ALL 

# ����Slurmģ��
module load slurm 

# ����RASPAĿ¼������ģ��
RASPA_DIR=/fs1/software/RASPA2/RASPA2-master

RASPA_DIR=/fs1/software/RASPA2/RASPA2-master  # ������Ŀ¼·��
export RASPA_DIR
export PATH=$RASPA_DIR/bin:$PATH
export LD_LIBRARY_PATH=$RASPA_DIR/lib:$LD_LIBRARY_PATH
export RASPA_SHARE_DIR=$RASPA_DIR/share/raspa
export RASPA_MOLECULES_DIR=$RASPA_SHARE_DIR/molecules
${RASPA_DIR}/bin/simulate